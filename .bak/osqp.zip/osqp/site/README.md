# OSQP Solver Website

Built with [Jekyll](https://jekyllrb.com/) and [Bootstrap](http://getbootstrap.com/).

## TODO

