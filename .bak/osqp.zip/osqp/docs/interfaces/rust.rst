.. _rust_interface:

Rust
======

The Rust interface is documented `here <https://docs.rs/osqp/>`_.
