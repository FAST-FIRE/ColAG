DOXYFILE = 'Doxyfile-mcss'

MAIN_PROJECT_URL = './index.html'
SHOW_UNDOCUMENTED = True

LINKS_NAVBAR1 = [
    ('Pages', 'pages', []),
    ('Classes', 'annotated', []),
    ('Files', 'files', [])
]
LINKS_NAVBAR2 = [
    ('<a href=\"https://github.com/robotology/osqp-eigen\">GitHub</a>', [])
]
