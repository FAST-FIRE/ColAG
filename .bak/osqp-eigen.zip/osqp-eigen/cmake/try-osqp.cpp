// This file is only available on OSQP >= 1.0.0
#include <osqp_api_functions.h>

int main()
{
  return 0;
}
