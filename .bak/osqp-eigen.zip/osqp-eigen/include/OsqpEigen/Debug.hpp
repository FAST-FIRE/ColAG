#ifndef OSQPEIGEN_DEBUG_HPP
#define OSQPEIGEN_DEBUG_HPP

#include <iostream>

namespace OsqpEigen
{
std::ostream& debugStream();
} // namespace OsqpEigen

#endif /* OSQPEIGEN_DEBUG_HPP */
